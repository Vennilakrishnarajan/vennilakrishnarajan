"""
AgroMind - Advanced Agronomic Soil Diagnostic Engine
=====================================================
POST /soil-report

Rule-based, deterministic, scientifically structured.
No external AI APIs. Fully explainable agronomic logic.
"""

from flask import Blueprint, request, jsonify
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import math

soil_report_bp = Blueprint("soil_report", __name__)

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS & THRESHOLDS
# ─────────────────────────────────────────────────────────────────────────────

PH_BANDS = [
    (float("-inf"), 5.5,  "Strongly Acidic"),
    (5.5,           6.5,  "Slightly Acidic"),
    (6.5,           7.5,  "Neutral (Optimal)"),
    (7.5,           8.5,  "Slightly Alkaline"),
    (8.5,           float("inf"), "Strongly Alkaline"),
]

NPK_BANDS = {
    "nitrogen":   [(0, 40, "Deficient"), (40,  120, "Optimal"), (120,  float("inf"), "Excess")],
    "phosphorus": [(0, 20, "Deficient"), (20,   60, "Optimal"),  (60,  float("inf"), "Excess")],
    "potassium":  [(0, 20, "Deficient"), (20,   60, "Optimal"),  (60,  float("inf"), "Excess")],
}

# Scoring weights used by the crop compatibility engine
CROP_DB: List[Dict] = [
    {
        "crop_name": "Rice",
        "botanical_name": "Oryza sativa",
        "optimal_ph": (5.5, 7.0),
        "optimal_temp": (20, 35),
        "optimal_rainfall": (150, 300),
        "optimal_humidity": (60, 90),
        "soil_types": ["clay", "loamy", "silty"],
        "nitrogen_need": "high",      # > 80 kg/ha
        "phosphorus_need": "medium",  # 20-60 kg/ha
        "potassium_need": "medium",
        "seasons": ["kharif", "summer"],
    },
    {
        "crop_name": "Wheat",
        "botanical_name": "Triticum aestivum",
        "optimal_ph": (6.0, 7.5),
        "optimal_temp": (10, 25),
        "optimal_rainfall": (30, 100),
        "optimal_humidity": (40, 70),
        "soil_types": ["loamy", "clay", "sandy loam"],
        "nitrogen_need": "high",
        "phosphorus_need": "medium",
        "potassium_need": "low",
        "seasons": ["rabi", "winter"],
    },
    {
        "crop_name": "Maize",
        "botanical_name": "Zea mays",
        "optimal_ph": (5.8, 7.0),
        "optimal_temp": (18, 32),
        "optimal_rainfall": (50, 150),
        "optimal_humidity": (50, 80),
        "soil_types": ["loamy", "sandy loam", "silt loam"],
        "nitrogen_need": "high",
        "phosphorus_need": "high",
        "potassium_need": "medium",
        "seasons": ["kharif", "spring", "summer"],
    },
    {
        "crop_name": "Soybean",
        "botanical_name": "Glycine max",
        "optimal_ph": (6.0, 7.0),
        "optimal_temp": (20, 30),
        "optimal_rainfall": (60, 170),
        "optimal_humidity": (55, 75),
        "soil_types": ["loamy", "sandy loam", "clay loam"],
        "nitrogen_need": "low",      # fixes atmospheric N
        "phosphorus_need": "medium",
        "potassium_need": "medium",
        "seasons": ["kharif", "summer"],
    },
    {
        "crop_name": "Cotton",
        "botanical_name": "Gossypium hirsutum",
        "optimal_ph": (5.8, 8.0),
        "optimal_temp": (21, 37),
        "optimal_rainfall": (50, 100),
        "optimal_humidity": (40, 70),
        "soil_types": ["black", "loamy", "clay"],
        "nitrogen_need": "medium",
        "phosphorus_need": "medium",
        "potassium_need": "high",
        "seasons": ["kharif", "summer"],
    },
    {
        "crop_name": "Chickpea",
        "botanical_name": "Cicer arietinum",
        "optimal_ph": (6.0, 8.0),
        "optimal_temp": (15, 29),
        "optimal_rainfall": (30, 80),
        "optimal_humidity": (30, 60),
        "soil_types": ["loamy", "sandy loam", "red laterite"],
        "nitrogen_need": "low",
        "phosphorus_need": "high",
        "potassium_need": "low",
        "seasons": ["rabi", "winter"],
    },
    {
        "crop_name": "Sugarcane",
        "botanical_name": "Saccharum officinarum",
        "optimal_ph": (6.0, 7.5),
        "optimal_temp": (20, 40),
        "optimal_rainfall": (100, 250),
        "optimal_humidity": (60, 85),
        "soil_types": ["loamy", "clay loam", "red laterite"],
        "nitrogen_need": "high",
        "phosphorus_need": "medium",
        "potassium_need": "high",
        "seasons": ["spring", "summer", "kharif"],
    },
    {
        "crop_name": "Groundnut",
        "botanical_name": "Arachis hypogaea",
        "optimal_ph": (5.5, 7.0),
        "optimal_temp": (20, 33),
        "optimal_rainfall": (50, 125),
        "optimal_humidity": (45, 70),
        "soil_types": ["sandy loam", "loamy", "red laterite"],
        "nitrogen_need": "low",
        "phosphorus_need": "high",
        "potassium_need": "medium",
        "seasons": ["kharif", "summer"],
    },
    {
        "crop_name": "Tomato",
        "botanical_name": "Solanum lycopersicum",
        "optimal_ph": (6.0, 7.0),
        "optimal_temp": (18, 29),
        "optimal_rainfall": (40, 120),
        "optimal_humidity": (50, 75),
        "soil_types": ["loamy", "sandy loam", "silt loam"],
        "nitrogen_need": "high",
        "phosphorus_need": "high",
        "potassium_need": "high",
        "seasons": ["rabi", "spring", "winter"],
    },
    {
        "crop_name": "Potato",
        "botanical_name": "Solanum tuberosum",
        "optimal_ph": (5.0, 6.5),
        "optimal_temp": (15, 25),
        "optimal_rainfall": (50, 120),
        "optimal_humidity": (60, 80),
        "soil_types": ["loamy", "sandy loam", "silt loam"],
        "nitrogen_need": "medium",
        "phosphorus_need": "high",
        "potassium_need": "high",
        "seasons": ["rabi", "winter"],
    },
    {
        "crop_name": "Onion",
        "botanical_name": "Allium cepa",
        "optimal_ph": (6.0, 7.5),
        "optimal_temp": (13, 28),
        "optimal_rainfall": (35, 100),
        "optimal_humidity": (40, 65),
        "soil_types": ["loamy", "sandy loam", "silty"],
        "nitrogen_need": "medium",
        "phosphorus_need": "medium",
        "potassium_need": "medium",
        "seasons": ["rabi", "winter"],
    },
    {
        "crop_name": "Sunflower",
        "botanical_name": "Helianthus annuus",
        "optimal_ph": (6.0, 7.5),
        "optimal_temp": (18, 35),
        "optimal_rainfall": (50, 130),
        "optimal_humidity": (40, 70),
        "soil_types": ["loamy", "sandy loam", "clay loam"],
        "nitrogen_need": "medium",
        "phosphorus_need": "medium",
        "potassium_need": "medium",
        "seasons": ["kharif", "rabi", "spring"],
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — SOIL CHEMISTRY CLASSIFICATION
# ─────────────────────────────────────────────────────────────────────────────

def classify_ph(ph: float) -> str:
    for lo, hi, label in PH_BANDS:
        if lo <= ph < hi:
            return label
    return "Unknown"


def classify_nutrient(value: float, nutrient: str) -> str:
    for lo, hi, label in NPK_BANDS[nutrient]:
        if lo <= value < hi:
            return label
    return "Unknown"


def soil_chemistry_classification(ph, nitrogen, phosphorus, potassium) -> Dict:
    return {
        "ph_classification": classify_ph(ph),
        "nitrogen_status":   classify_nutrient(nitrogen,   "nitrogen"),
        "phosphorus_status": classify_nutrient(phosphorus, "phosphorus"),
        "potassium_status":  classify_nutrient(potassium,  "potassium"),
    }


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — AGRONOMIC INTERPRETATION
# ─────────────────────────────────────────────────────────────────────────────

PH_INTERPRETATION = {
    "Strongly Acidic": (
        "Soil pH below 5.5 indicates strong acidity. At this level, aluminium and "
        "manganese ions become soluble and reach phytotoxic concentrations. Phosphorus "
        "becomes unavailable due to fixation with iron and aluminium oxides. "
        "Beneficial soil bacteria populations decline sharply, reducing organic matter "
        "mineralisation and suppressing nitrogen cycling. Expected yield losses of "
        "25–60% are common for sensitive crops such as wheat and legumes."
    ),
    "Slightly Acidic": (
        "Soil pH between 5.5 and 6.5 is mildly acidic. Most macronutrients (N, P, K) "
        "remain plant-available, though phosphorus availability may be marginally "
        "reduced below pH 6.0. Molybdenum availability decreases, which can impair "
        "nitrogen fixation in legumes. Microbial activity is generally adequate, with "
        "minimal yield penalties for tolerant crops."
    ),
    "Neutral (Optimal)": (
        "Soil pH between 6.5 and 7.5 is the agronomic optimum for most field crops. "
        "All macronutrients (N, P, K, Ca, Mg, S) and most micronutrients are at "
        "peak bioavailability. Nitrification bacteria and mycorrhizal associations "
        "function optimally, supporting both nutrient cycling and root colonisation. "
        "This pH range is associated with maximum achievable yields under standard "
        "management."
    ),
    "Slightly Alkaline": (
        "Soil pH between 7.5 and 8.5 introduces micronutrient availability constraints. "
        "Iron, manganese, zinc, and boron undergo precipitation, causing interveinal "
        "chlorosis and stunted growth in susceptible crops. Phosphorus solubility "
        "declines due to calcium phosphate precipitation. Organic matter decomposition "
        "may be slower, and some nitrogen can be lost via denitrification in waterlogged "
        "conditions. Moderate yield reductions (10–30%) are possible without correction."
    ),
    "Strongly Alkaline": (
        "Soil pH above 8.5 creates severe micronutrient lockup. Iron deficiency "
        "(lime-induced chlorosis), zinc deficiency, and boron toxicity are common. "
        "Phosphorus is strongly fixed by calcium, rendering applied P fertilisers "
        "largely ineffective. Salt accumulation is frequently co-occurring. "
        "Sodicity risk is elevated, degrading soil structure and hydraulic conductivity. "
        "Without active amendment, yield potential is severely compromised."
    ),
}

NUTRIENT_INTERPRETATION = {
    "nitrogen": {
        "Deficient": (
            "Nitrogen deficiency below 40 kg/ha severely limits vegetative growth. "
            "Nitrogen is the primary constituent of chlorophyll, amino acids, and "
            "nucleic acids. Symptoms include uniform yellowing starting from older "
            "leaves (chlorosis), stunted shoots, and pale green canopy coloration. "
            "Protein synthesis is impaired, reducing grain fill and biomass accumulation. "
            "Yield losses of 30–50% are expected without correction."
        ),
        "Optimal": (
            "Nitrogen level is within the optimal range (40–120 kg/ha). Adequate "
            "nitrogen supports vigorous vegetative growth, robust leaf area development, "
            "and efficient photosynthetic capacity. Canopy development and grain "
            "filling proceed normally. Maintaining this range through split-dose "
            "applications is recommended."
        ),
        "Excess": (
            "Nitrogen excess above 120 kg/ha poses multiple agronomic risks. Excessive "
            "vegetative growth increases lodging susceptibility and reduces harvest "
            "index. Luxury nitrogen uptake promotes succulent tissue that is highly "
            "attractive to aphids and fungal pathogens. Nitrate leaching to groundwater "
            "and nitrous oxide volatilisation are significant environmental concerns. "
            "Grain quality (protein content and test weight) may paradoxically decline "
            "due to dilution effects."
        ),
    },
    "phosphorus": {
        "Deficient": (
            "Phosphorus deficiency below 20 kg/ha critically impairs root architecture "
            "and energy metabolism. Phosphorus drives ATP synthesis, root meristem "
            "development, and cell division. Deficiency results in sparse, shallow "
            "root systems with poor mycorrhizal colonisation, restricting water and "
            "nutrient uptake across the entire soil profile. Purple-red discolouration "
            "of leaf undersides (anthocyanin accumulation) is the diagnostic visual "
            "symptom. Delayed crop maturity and reduced grain set are consistent outcomes."
        ),
        "Optimal": (
            "Phosphorus levels between 20–60 kg/ha are adequate. Strong root system "
            "development, early crop establishment, and efficient water-use are supported. "
            "Energy transfer processes for photosynthesis and nutrient translocation "
            "operate without constraint."
        ),
        "Excess": (
            "Excess phosphorus above 60 kg/ha induces secondary zinc and iron deficiencies "
            "through competitive ion antagonism. Soil phosphorus saturation leads to "
            "eutrophication risk in adjacent water bodies via surface runoff. No "
            "additional yield benefit is achieved beyond the optimum; phosphorus "
            "applications should be suspended until soil levels fall within range."
        ),
    },
    "potassium": {
        "Deficient": (
            "Potassium deficiency below 20 kg/ha severely reduces crop stress tolerance "
            "and structural integrity. Potassium regulates stomatal opening and closing, "
            "osmotic adjustment under drought, phloem loading of sugars, and cell wall "
            "rigidity. Deficient crops exhibit scorched leaf margins (marginal necrosis), "
            "weak stalks prone to lodging, reduced disease resistance, and poor grain "
            "filling. Susceptibility to drought, frost, and fungal pathogens increases "
            "markedly."
        ),
        "Optimal": (
            "Potassium in the 20–60 kg/ha range supports optimal water-use efficiency, "
            "disease resistance, and structural strength. Starch and sugar translocation "
            "to storage organs is unimpeded, contributing to high harvest index and "
            "grain quality."
        ),
        "Excess": (
            "Excess potassium above 60 kg/ha causes antagonistic suppression of "
            "calcium and magnesium uptake (cation antagonism), potentially inducing "
            "grass tetany in forage crops and tip-burn in leafy vegetables. Soil "
            "salinisation risk increases in arid conditions. Potassium applications "
            "should be withheld and irrigation adjusted to facilitate leaching."
        ),
    },
}


def build_agronomic_interpretation(ph, ph_class, n_status, p_status, k_status) -> str:
    parts = []

    # pH interpretation
    ph_text = PH_INTERPRETATION.get(ph_class, "")
    if ph_text:
        parts.append(f"[pH {ph:.1f} — {ph_class}] {ph_text}")

    # Nutrient interpretations
    for nutrient, status, label in [
        ("nitrogen",   n_status, f"N {ph:.1f} kg/ha"),
        ("phosphorus", p_status, "P"),
        ("potassium",  k_status, "K"),
    ]:
        text = NUTRIENT_INTERPRETATION[nutrient].get(status, "")
        if text:
            parts.append(f"[{nutrient.capitalize()} — {status}] {text}")

    return " | ".join(parts) if parts else "No significant imbalances detected."


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — CORRECTION STRATEGY
# ─────────────────────────────────────────────────────────────────────────────

def build_corrections(ph_class, n_status, p_status, k_status) -> List[Dict]:
    corrections = []

    # pH corrections
    if ph_class == "Strongly Acidic":
        corrections.append({
            "issue": "Strongly Acidic Soil",
            "amendment": "Agricultural Lime (CaCO₃)",
            "rate": "2–5 tonnes/ha depending on buffer pH and soil texture",
            "notes": (
                "Apply dolomitic lime to supply both Ca and Mg if Mg is also deficient. "
                "Incorporate into the top 20 cm via tillage. Re-test pH after 3 months. "
                "Target pH 6.0–6.5 for most field crops."
            ),
        })
    elif ph_class == "Slightly Acidic":
        corrections.append({
            "issue": "Slightly Acidic Soil",
            "amendment": "Light lime or wood-ash application",
            "rate": "0.5–1 tonne/ha",
            "notes": "Monitor pH annually. Slightly acidic conditions are tolerable for acid-tolerant crops.",
        })
    elif ph_class == "Slightly Alkaline":
        corrections.append({
            "issue": "Slightly Alkaline Soil",
            "amendment": "Gypsum (CaSO₄·2H₂O) + Organic Matter (FYM/Compost)",
            "rate": "Gypsum 200–500 kg/ha; Compost 5–10 tonnes/ha",
            "notes": (
                "Gypsum supplies sulphur and calcium without affecting pH, displacing "
                "excess sodium. Organic matter acidifies the root zone, improves "
                "buffering, and enhances micronutrient chelation. Repeat annually."
            ),
        })
    elif ph_class == "Strongly Alkaline":
        corrections.append({
            "issue": "Strongly Alkaline / Sodic Soil",
            "amendment": "Elemental Sulphur + Gypsum + Heavy Organic Matter addition",
            "rate": "Sulphur 250–750 kg/ha; Gypsum 500–1000 kg/ha; Compost 10–15 t/ha",
            "notes": (
                "Elemental sulphur is oxidised to H₂SO₄ by Thiobacillus bacteria, "
                "directly acidifying the soil matrix. Combine with leaching irrigations "
                "to flush displaced salts. Micronutrient foliar sprays (Fe, Zn, Mn) "
                "are recommended as a short-term bridge measure."
            ),
        })

    # Nitrogen
    if n_status == "Deficient":
        corrections.append({
            "issue": "Nitrogen Deficiency",
            "amendment": "Urea (46-0-0) or FYM / Green Manure",
            "rate": "Urea: 100–175 kg/ha in 2–3 split doses; Compost: 5–8 t/ha",
            "notes": (
                "Apply first split at sowing, second at active tillering/vegetative stage, "
                "and third (if required) at panicle initiation. Nitrification inhibitors "
                "(e.g., neem-coated urea) reduce volatilisation losses. For organic "
                "systems, vermicompost or legume green manure is recommended."
            ),
        })
    elif n_status == "Excess":
        corrections.append({
            "issue": "Nitrogen Excess",
            "amendment": "Withhold nitrogen applications; Leaching irrigation",
            "rate": "N/A",
            "notes": (
                "Cease all nitrogenous fertiliser until the next growing cycle. "
                "Apply 2–3 deep irrigation events to leach nitrate below the root zone. "
                "Consider a high C:N cover crop (wheat straw, sorghum) to immobilise "
                "excess mineral nitrogen biologically."
            ),
        })

    # Phosphorus
    if p_status == "Deficient":
        corrections.append({
            "issue": "Phosphorus Deficiency",
            "amendment": "DAP (18-46-0) or SSP (0-16-0)",
            "rate": "DAP: 100–150 kg/ha at basal; SSP: 250–375 kg/ha",
            "notes": (
                "Incorporate phosphate fertilisers into the seed zone at sowing for "
                "maximum root interception. In acidic soils, rock phosphate can be "
                "effective. Mycorrhizal inoculants increase phosphorus uptake efficiency "
                "by 15–40% and should be considered as a supplementary measure."
            ),
        })
    elif p_status == "Excess":
        corrections.append({
            "issue": "Phosphorus Excess",
            "amendment": "Withhold P applications; Zinc supplementation",
            "rate": "Zinc sulphate 25 kg/ha as corrective measure",
            "notes": (
                "Excess P induces secondary zinc deficiency via antagonism. Apply zinc "
                "sulphate foliar sprays (0.5% solution) or soil application of ZnSO₄. "
                "Do not apply phosphate fertilisers for 1–2 crop cycles."
            ),
        })

    # Potassium
    if k_status == "Deficient":
        corrections.append({
            "issue": "Potassium Deficiency",
            "amendment": "MOP / Muriate of Potash (0-0-60) or SOP (0-0-50)",
            "rate": "MOP: 50–100 kg/ha; SOP preferred for chloride-sensitive crops",
            "notes": (
                "Potassium is mobile in the phloem; split applications improve use "
                "efficiency. SOP (Sulphate of Potash) is preferred for tobacco, "
                "potato, and fruits where chloride tolerance is low. K2O from wood "
                "ash (5–7% K₂O) is an organic option at 500–800 kg/ha."
            ),
        })
    elif k_status == "Excess":
        corrections.append({
            "issue": "Potassium Excess",
            "amendment": "Leaching irrigation + Calcium/Magnesium supplementation",
            "rate": "Calcium nitrate 100–150 kg/ha; Magnesium sulphate 50 kg/ha",
            "notes": (
                "Flush excess potassium via leaching irrigations. Supplement calcium "
                "and magnesium to counter cation antagonism. Avoid potassic fertilisers "
                "for the next 2 seasons."
            ),
        })

    if not corrections:
        corrections.append({
            "issue": "No Major Deficiencies Detected",
            "amendment": "Maintenance fertilisation only",
            "rate": "Adjust based on crop off-take calculations",
            "notes": (
                "Soil chemistry is within acceptable ranges. Continue regular soil "
                "testing (bi-annual) and apply maintenance doses aligned with crop "
                "nutrient removal rates to sustain long-term soil fertility."
            ),
        })

    return corrections


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — CROP COMPATIBILITY SCORING ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def _score_range(value: float, lo: float, hi: float, weight: float = 1.0) -> Tuple[float, float]:
    """Return (score, max_score). Full score if in range, partial if within 20% tolerance."""
    if lo <= value <= hi:
        return weight, weight
    tolerance = (hi - lo) * 0.20
    if lo - tolerance <= value < lo:
        ratio = 1 - (lo - value) / tolerance
        return round(weight * ratio, 4), weight
    if hi < value <= hi + tolerance:
        ratio = 1 - (value - hi) / tolerance
        return round(weight * ratio, 4), weight
    return 0.0, weight


def _npk_need_score(value: float, need_level: str, nutrient: str) -> Tuple[float, float]:
    """Score nutrient value against crop's need level. Returns (score, weight=1.0)."""
    bands = NPK_BANDS[nutrient]
    # Find actual band label
    actual_status = "Deficient"
    for lo, hi, label in bands:
        if lo <= value < hi:
            actual_status = label
            break

    match = {
        "high":   {"Optimal": 1.0, "Excess": 0.7, "Deficient": 0.0},
        "medium": {"Optimal": 1.0, "Deficient": 0.4, "Excess": 0.4},
        "low":    {"Optimal": 0.8, "Deficient": 0.9, "Excess": 0.0},  # N-fixers prefer lower N
    }
    score = match.get(need_level, {}).get(actual_status, 0.5)
    return score, 1.0


def score_crop(crop: Dict, soil_type: str, temperature: float, humidity: float,
               rainfall: float, ph: float, nitrogen: float, phosphorus: float,
               potassium: float, season: str) -> Tuple[float, List[str]]:
    """
    Explainable scoring. Returns (raw_score_0_to_1, reasons[]).
    Weights: pH(25), Temp(20), Rainfall(15), Humidity(10), N(10), P(10), K(10), soil(5), season(bonus 5)
    """
    total_score = 0.0
    total_max   = 0.0
    reasons     = []

    # 1. pH (weight 25)
    ph_lo, ph_hi = crop["optimal_ph"]
    s, m = _score_range(ph, ph_lo, ph_hi, 25)
    total_score += s; total_max += m
    if s == m:
        reasons.append(f"pH {ph:.1f} is within optimal range ({ph_lo}–{ph_hi}) for this crop")
    elif s > 0:
        reasons.append(f"pH {ph:.1f} is marginally outside optimal range ({ph_lo}–{ph_hi})")
    else:
        reasons.append(f"pH {ph:.1f} is incompatible with optimal range ({ph_lo}–{ph_hi})")

    # 2. Temperature (weight 20)
    t_lo, t_hi = crop["optimal_temp"]
    s, m = _score_range(temperature, t_lo, t_hi, 20)
    total_score += s; total_max += m
    if s == m:
        reasons.append(f"Temperature {temperature}°C suits optimal growth range ({t_lo}–{t_hi}°C)")
    elif s > 0:
        reasons.append(f"Temperature {temperature}°C is near the edge of optimal range ({t_lo}–{t_hi}°C)")
    else:
        reasons.append(f"Temperature {temperature}°C falls outside optimal range ({t_lo}–{t_hi}°C)")

    # 3. Rainfall (weight 15)
    r_lo, r_hi = crop["optimal_rainfall"]
    s, m = _score_range(rainfall, r_lo, r_hi, 15)
    total_score += s; total_max += m
    if s == m:
        reasons.append(f"Rainfall {rainfall} mm/month is adequate ({r_lo}–{r_hi} mm needed)")
    elif s == 0:
        reasons.append(f"Rainfall {rainfall} mm/month is insufficient or excessive ({r_lo}–{r_hi} mm optimal)")

    # 4. Humidity (weight 10)
    h_lo, h_hi = crop["optimal_humidity"]
    s, m = _score_range(humidity, h_lo, h_hi, 10)
    total_score += s; total_max += m
    if s < m:
        reasons.append(f"Humidity {humidity}% is sub-optimal (crop needs {h_lo}–{h_hi}%)")
    else:
        reasons.append(f"Humidity {humidity}% is suitable")

    # 5. Nitrogen (weight 10)
    s, m = _npk_need_score(nitrogen, crop["nitrogen_need"], "nitrogen")
    s *= 10; m *= 10
    total_score += s; total_max += m
    if s / m >= 0.8:
        reasons.append(f"Nitrogen level ({nitrogen} kg/ha) meets crop's {crop['nitrogen_need']} nitrogen demand")
    else:
        reasons.append(f"Nitrogen level ({nitrogen} kg/ha) does not fully meet crop's {crop['nitrogen_need']} nitrogen demand")

    # 6. Phosphorus (weight 10)
    s, m = _npk_need_score(phosphorus, crop["phosphorus_need"], "phosphorus")
    s *= 10; m *= 10
    total_score += s; total_max += m
    if s / m >= 0.8:
        reasons.append(f"Phosphorus ({phosphorus} kg/ha) suits crop's {crop['phosphorus_need']} phosphorus demand")

    # 7. Potassium (weight 10)
    s, m = _npk_need_score(potassium, crop["potassium_need"], "potassium")
    s *= 10; m *= 10
    total_score += s; total_max += m
    if s / m >= 0.8:
        reasons.append(f"Potassium ({potassium} kg/ha) suits crop's {crop['potassium_need']} potassium demand")

    # 8. Soil type (weight 5)
    soil_lower = soil_type.lower().strip()
    soil_match = any(s in soil_lower or soil_lower in s for s in crop["soil_types"])
    if soil_match:
        total_score += 5; reasons.append(f"Soil type '{soil_type}' is compatible with this crop")
    else:
        reasons.append(f"Soil type '{soil_type}' is not in the preferred list for this crop")
    total_max += 5

    # 9. Season bonus (weight 5)
    season_lower = season.lower().strip()
    season_match = any(season_lower in s or s in season_lower for s in crop["seasons"])
    if season_match:
        total_score += 5; reasons.append(f"Season '{season}' aligns with crop's growing calendar")
    else:
        reasons.append(f"Season '{season}' may not be ideal for this crop")
    total_max += 5

    raw = total_score / total_max if total_max > 0 else 0
    return raw, reasons


def crop_compatibility_analysis(soil_type, temperature, humidity, rainfall,
                                ph, nitrogen, phosphorus, potassium, season,
                                top_n: int = 5) -> List[Dict]:
    results = []
    for crop in CROP_DB:
        raw, reasons = score_crop(
            crop, soil_type, temperature, humidity, rainfall,
            ph, nitrogen, phosphorus, potassium, season
        )
        score_100 = round(raw * 100, 2)
        results.append({
            "crop_name":      crop["crop_name"],
            "botanical_name": crop["botanical_name"],
            "score":          score_100,
            "suitability_pct": score_100,
            "reasons":        reasons,
        })

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_n]


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 — YIELD RISK ASSESSMENT
# ─────────────────────────────────────────────────────────────────────────────

def assess_yield_risk(ph_class: str, n_status: str, p_status: str, k_status: str) -> Tuple[str, str]:
    """Returns (risk_level, explanation)."""
    deficiencies = [s for s in [n_status, p_status, k_status] if s == "Deficient"]
    excess_count  = [s for s in [n_status, p_status, k_status] if s == "Excess"]

    ph_risk = ph_class in ("Strongly Acidic", "Strongly Alkaline")
    ph_moderate = ph_class in ("Slightly Acidic", "Slightly Alkaline")

    total_stress_factors = len(deficiencies) + len(excess_count) + (2 if ph_risk else (1 if ph_moderate else 0))

    if total_stress_factors >= 3 or (len(deficiencies) >= 2) or (ph_risk and len(deficiencies) >= 1):
        level = "High"
        explanation = (
            f"Multiple concurrent stressors detected: {len(deficiencies)} nutrient deficiency(ies), "
            f"{len(excess_count)} excess nutrient(s), and pH classified as '{ph_class}'. "
            "Under these conditions, synergistic negative interactions between soil factors "
            "are expected to reduce yield by 30–60% or more without immediate corrective action."
        )
    elif total_stress_factors >= 1:
        level = "Moderate"
        explanation = (
            f"One or two sub-optimal soil conditions identified (pH: {ph_class}; "
            f"deficiencies: {len(deficiencies)}; excess: {len(excess_count)}). "
            "With targeted corrective amendments, yield losses can be limited to 10–25%. "
            "Close monitoring and timely fertiliser management are advised."
        )
    else:
        level = "Low"
        explanation = (
            "Soil chemistry is balanced. pH is near-neutral, and N, P, K levels are within "
            "optimal ranges. Risk of yield loss from nutritional constraints is minimal. "
            "Standard agronomic practices and maintenance applications are sufficient."
        )

    return level, explanation


# ─────────────────────────────────────────────────────────────────────────────
# INPUT VALIDATION
# ─────────────────────────────────────────────────────────────────────────────

REQUIRED_FIELDS = {
    "soil_type":   str,
    "temperature": (int, float),
    "humidity":    (int, float),
    "rainfall":    (int, float),
    "ph":          (int, float),
    "nitrogen":    (int, float),
    "phosphorus":  (int, float),
    "potassium":   (int, float),
    "season":      str,
}

NUMERIC_RANGES = {
    "temperature": (-10, 60,   "°C"),
    "humidity":    (0,   100,  "%"),
    "rainfall":    (0,   1000, "mm/month"),
    "ph":          (0,   14,   "pH units"),
    "nitrogen":    (0,   500,  "kg/ha"),
    "phosphorus":  (0,   300,  "kg/ha"),
    "potassium":   (0,   300,  "kg/ha"),
}


def validate_input(data: dict) -> Tuple[bool, str]:
    for field, expected_type in REQUIRED_FIELDS.items():
        if field not in data:
            return False, f"Missing required field: '{field}'"
        if not isinstance(data[field], expected_type):
            return False, f"Field '{field}' must be of type {expected_type}"

    for field, (lo, hi, unit) in NUMERIC_RANGES.items():
        val = data[field]
        if not (lo <= val <= hi):
            return False, f"Field '{field}' value {val} is out of plausible range [{lo}–{hi} {unit}]"

    if not data["soil_type"].strip():
        return False, "Field 'soil_type' must not be empty"
    if not data["season"].strip():
        return False, "Field 'season' must not be empty"

    return True, ""


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────

@soil_report_bp.route("/soil-report", methods=["POST"])
def soil_report():
    """
    POST /soil-report
    Advanced Agronomic Soil Diagnostic Engine.
    Returns a fully explainable, rule-based soil analysis report.
    """
    if not request.is_json:
        return jsonify({"status": "error", "message": "Content-Type must be application/json"}), 400

    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"status": "error", "message": "Invalid or malformed JSON body"}), 400

    # ── Validate ──────────────────────────────────────────────────────────────
    valid, err_msg = validate_input(data)
    if not valid:
        return jsonify({"status": "error", "message": err_msg}), 422

    # ── Extract inputs ────────────────────────────────────────────────────────
    soil_type   = data["soil_type"].strip()
    temperature = float(data["temperature"])
    humidity    = float(data["humidity"])
    rainfall    = float(data["rainfall"])
    ph          = float(data["ph"])
    nitrogen    = float(data["nitrogen"])
    phosphorus  = float(data["phosphorus"])
    potassium   = float(data["potassium"])
    season      = data["season"].strip()

    # ── Section 1: Chemistry Classification ──────────────────────────────────
    soil_analysis = soil_chemistry_classification(ph, nitrogen, phosphorus, potassium)
    ph_class  = soil_analysis["ph_classification"]
    n_status  = soil_analysis["nitrogen_status"]
    p_status  = soil_analysis["phosphorus_status"]
    k_status  = soil_analysis["potassium_status"]

    # ── Section 2: Agronomic Interpretation ──────────────────────────────────
    interpretation = build_agronomic_interpretation(ph, ph_class, n_status, p_status, k_status)

    # ── Section 3: Correction Strategy ───────────────────────────────────────
    corrections = build_corrections(ph_class, n_status, p_status, k_status)

    # ── Section 4: Crop Compatibility ────────────────────────────────────────
    recommended_crops = crop_compatibility_analysis(
        soil_type, temperature, humidity, rainfall,
        ph, nitrogen, phosphorus, potassium, season
    )

    # ── Section 5: Yield Risk Assessment ─────────────────────────────────────
    risk_level, risk_explanation = assess_yield_risk(ph_class, n_status, p_status, k_status)

    # ── Section 6: Final Response ─────────────────────────────────────────────
    response = {
        "status": "success",
        "input_summary": {
            "soil_type":   soil_type,
            "season":      season,
            "temperature": temperature,
            "humidity":    humidity,
            "rainfall":    rainfall,
            "ph":          ph,
            "nitrogen":    nitrogen,
            "phosphorus":  phosphorus,
            "potassium":   potassium,
        },
        "soil_analysis": soil_analysis,
        "agronomic_interpretation": interpretation,
        "correction_recommendations": corrections,
        "yield_risk_level":       risk_level,
        "yield_risk_explanation": risk_explanation,
        "recommended_crops":      recommended_crops,
    }

    return jsonify(response), 200