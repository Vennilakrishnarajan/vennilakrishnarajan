from flask import Flask, render_template
from soil_report import soil_report_bp

app = Flask(__name__)
app.register_blueprint(soil_report_bp)

@app.route("/")
def home():
    return render_template("index.html")

import os

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)